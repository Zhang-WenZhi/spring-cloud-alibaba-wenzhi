package com.wenzhi.spring_cloud_alibaba_wenzhi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudAlibabaWenzhiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudAlibabaWenzhiApplication.class, args);
	}

}
