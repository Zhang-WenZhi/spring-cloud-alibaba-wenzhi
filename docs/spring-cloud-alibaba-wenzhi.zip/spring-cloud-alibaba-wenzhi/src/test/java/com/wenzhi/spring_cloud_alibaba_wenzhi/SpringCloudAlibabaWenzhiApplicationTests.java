package com.wenzhi.spring_cloud_alibaba_wenzhi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudAlibabaWenzhiApplicationTests {

	@Test
	void contextLoads() {
	}

}
