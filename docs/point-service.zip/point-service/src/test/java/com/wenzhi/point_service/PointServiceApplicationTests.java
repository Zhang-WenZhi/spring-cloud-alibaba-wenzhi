package com.wenzhi.point_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
